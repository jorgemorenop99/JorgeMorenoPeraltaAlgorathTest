package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import algorath.*;

class UserTests {
	
	@BeforeEach
	void prepareTests() {
		User u1 = new User(501, "Anthony");
		User u2 = new User(502, "Steve");
		User u3 = new User(503, "Clint");
		User u4 = new User(504, "Tom");
		
		u1.addConnection(502);
		u2.addConnection(503);
		
	}
	@AfterEach
	public void reset() {
		for(User u : User.userList()) {
			u.deleteUser();
		}
	}

	@Test    // Testing how we get a given user from the db
	void testGetUserFromDB() {
		User u = new User(502);
		assertEquals(u.getName(), "Steve");
	}

	@Test   
	void testAddUserToDb() { 
		User u = new User(15,"Sam"); // added to db
		List<User> list = User.userList();
		boolean conts = false;
		for(User aux : list) {
			if(aux.getName().equals("Sam") ) {
				conts = true;
			}
		}
		assertTrue(conts);
	}
	
	@Test   
	void testAddDuplicateID() { 
		 User u = new User(506,"Stephen");
			assertThrows(Exception.class, () -> u.setUserID(502));
	}

	@Test
	void testUserList() {
		List<User> list = User.userList();
		boolean a = false ,b = false,c=false ,d = false;
		for(User u : list) { //We check that all the users created before are listed
			if(u.getName().equals("Anthony")) a = true;
			if(u.getName().equals("Steve")) b = true;
			if(u.getName().equals("Clint")) c = true;
			if(u.getName().equals("Tom")) d = true;
		}
		assertTrue(a&&b&&c&&d);
	}

	@Test
	void testSetUserID() {
		User u = new User(502);
		u.setUserID(602);
		u = new User(602);
		assertEquals(u.getName(), "Steve");
		assertEquals(u.getUserID(), 602);

	}

	@Test
	void testSetName() {
		User u = new User(503);	
		u.setName("James");
		/////We load again from db to check its already changed on it
		u = new User (503);
		assertEquals(u.getName(), "James");
		}

	@Test
	void testDeleteUser() {
		User u = new User(503);
		u.deleteUser();
		for(User aux : User.userList()) {
			if(aux.equals(u)) {
				fail();
			}
		}
		
	}

	@Test
	void testAddConnection() {
		User u1 = new User(501);
		User u2 = new User(504);
		u1.addConnection(u2.getUserID());
		assertTrue(u1.getUsersConnected().contains(u2));
		assertTrue(u2.getUsersConnected().contains(u1));

	}
	
	@Test
	void testAddAnExistingConnection() {
		User u1 = new User(501);
		User u2 = new User(502);
		assertThrows(Exception.class, () -> u1.addConnection(u2.getUserID()));
		
	}
	
	@Test
	void testAddAnExistingConnectionReverseOrder() {
		//501 is already connected to 502
		// We will try to connect 502 to 501 and check how it throws the exception
		User u1 = new User(502);
		User u2 = new User(501);
		assertThrows(Exception.class, () -> u1.addConnection(u2.getUserID()));
		
	}

	@Test
	void testDeleteConnection() {
		//Connection between 501 and 502 already exists
		User u1 = new User(501);
		User u2 = new User(502);
		assertTrue(u1.getUsersConnected().contains(u2));
		assertTrue(u2.getUsersConnected().contains(u1));
		
		u1.deleteConnection(502);
		
		assertFalse(u1.getUsersConnected().contains(u2));
		assertFalse(u2.getUsersConnected().contains(u1));

		
	}

	@Test
	void testEqualsObject() {
		User u1 = new User(16,"Sam");
		User u2 = new User(16);
		assertTrue(u1.equals(u2));
	}

}
