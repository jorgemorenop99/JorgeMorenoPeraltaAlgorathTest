package winB;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import algorath.User;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddUserFrame extends JFrame {

	private JPanel contentPane;
	private JTextField IdField;
	private JTextField nameField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddUserFrame frame = new AddUserFrame(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param al 
	 */
	public AddUserFrame(JFrame f) {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 386, 238);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton AddButton = new JButton("Add the new User");
		AddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = 0;
				String name="";
				try {
					 id = Integer.parseInt(IdField.getText());
					 name = nameField.getText();
				}catch(Exception ex){
					ErrorFrame f = new ErrorFrame("The values of the fields are not valid");
					f.setVisible(true);				
				}
				try {
					User u = new User(id,name);
					dispose();
					MainWindow.main(null);
					
				}catch(Exception er){
					ErrorFrame f = new ErrorFrame("The ID is already used");
					f.setVisible(true);				
				}
				
			}
		});
		AddButton.setBounds(84, 136, 187, 21);
		contentPane.add(AddButton);
		
		IdField = new JTextField();
		IdField.setBounds(23, 86, 96, 19);
		contentPane.add(IdField);
		IdField.setColumns(10);
		
		nameField = new JTextField();
		nameField.setBounds(212, 86, 96, 19);
		contentPane.add(nameField);
		nameField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("User id:");
		lblNewLabel.setBounds(48, 63, 45, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setBounds(239, 63, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Add new User:");
		lblNewLabel_2.setFont(new Font("VAGRounded BT", Font.ITALIC, 18));
		lblNewLabel_2.setBounds(117, 28, 134, 13);
		contentPane.add(lblNewLabel_2);
	}
}
