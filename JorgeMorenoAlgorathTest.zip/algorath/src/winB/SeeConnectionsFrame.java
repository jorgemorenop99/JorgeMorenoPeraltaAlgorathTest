package winB;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import algorath.User;
import javax.swing.JLabel;
import java.awt.Font;

public class SeeConnectionsFrame extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeeConnectionsFrame frame = new SeeConnectionsFrame(0);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param id 
	 */
	public SeeConnectionsFrame(int id) {
		
		User u = new User(id);
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 772, 380);		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		lblNewLabel = new JLabel("Connections of "+ u.getName() + " (id = " + u.getUserID() + ")");
	    lblNewLabel.setBounds(58, 49, 244, 13);
	    contentPane.add(lblNewLabel);
		
		initializeTable(u);		
	}
	
	private void initializeTable(User u) {
		table = new JTable();

	    DefaultTableModel daDefaultTableModel = new DefaultTableModel(0, 0);

	    String[] columnNames = new String[] {"User ID", "Name"};

	    daDefaultTableModel.setColumnIdentifiers(columnNames);

	   loadTable(daDefaultTableModel, u);
	   
	    table.setModel(daDefaultTableModel);
	    JScrollPane scrollPane = new JScrollPane(table);
	    scrollPane.setBounds(10, 72, 327, 244);
	    getContentPane().add(scrollPane);
	    
	    lblNewLabel_1 = new JLabel("Stats");
	    lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 22));
	    lblNewLabel_1.setBounds(453, 38, 68, 24);
	    contentPane.add(lblNewLabel_1);
	    
	    lblNewLabel_2 = new JLabel("Number of Connections: "+ u.getUsersConnected().size());
	    lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
	    lblNewLabel_2.setBounds(357, 86, 190, 13);
	    contentPane.add(lblNewLabel_2);
	    
	    lblNewLabel_3 = new JLabel("Average number of Connections: " + User.getAverage());
	    lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
	    lblNewLabel_3.setBounds(357, 135, 231, 13);
	    contentPane.add(lblNewLabel_3);
	    
	    lblNewLabel_4 = new JLabel("You have more connections \n than " + String.format("%.2f", u.getStats()) + "% of the users");
	    lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
	    lblNewLabel_4.setBounds(357, 190, 321, 24);
	    contentPane.add(lblNewLabel_4);
	    
	    



	  }
public static void loadTable(DefaultTableModel daDefaultTableModel, User u) {
		
		for(User a : u.getUsersConnected() ) {
		    daDefaultTableModel.addRow(new Object[] {a.getUserID(), a.getName()});

		}
		
		
	}

}
