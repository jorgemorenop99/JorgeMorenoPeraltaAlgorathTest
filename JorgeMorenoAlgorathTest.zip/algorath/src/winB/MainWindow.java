package winB;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.TableColumn;

import algorath.User;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class MainWindow {

	private JFrame frame;
	private JTable table;
	DefaultTableModel daDefaultTableModel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 701, 457);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewUser = new JButton("Add new User");
		btnNewUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddUserFrame f = new AddUserFrame(frame);
				f.setVisible(true);	
				frame.dispose();
			}
		});
		btnNewUser.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewUser.setBounds(445, 74, 221, 30);
		frame.getContentPane().add(btnNewUser);
		
		JButton btnNewConnection = new JButton("Add new Connection");
		btnNewConnection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddNewConnectionFrame f = new AddNewConnectionFrame(frame);
				f.setVisible(true);	
			}
		});
		btnNewConnection.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewConnection.setBounds(445, 156, 221, 30);
		frame.getContentPane().add(btnNewConnection);
		
		JButton btnSeeConnections = new JButton("See connections and stats");
		btnSeeConnections.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = table.getSelectedRow();
				if(id >= 0) {
					id = (int) table.getValueAt(id, 0);
					SeeConnectionsFrame f = new SeeConnectionsFrame(id);
					f.setVisible(true);
				}else {
					ErrorFrame f = new ErrorFrame("You need to select an user before this operation");
					f.setVisible(true);
				}
					
			}
		});
		btnSeeConnections.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSeeConnections.setBounds(445, 238, 221, 30);
		frame.getContentPane().add(btnSeeConnections);
		
		JButton btnDeleteUser = new JButton("Delete user");
		btnDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = table.getSelectedRow();
				id = (int) table.getValueAt(id, 0);
				User u = new User(id);
				u.deleteUser();
				frame.dispose();
				MainWindow.main(null);		
			}
		});
		btnDeleteUser.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDeleteUser.setBounds(445, 331, 221, 30);
		frame.getContentPane().add(btnDeleteUser);
		
		
		
		initializeTable();		
	}

	private void initializeTable() {
		table = new JTable();

	     daDefaultTableModel = new DefaultTableModel(0, 0);

	    String[] columnNames = new String[] {"User ID", "Name"};

	    daDefaultTableModel.setColumnIdentifiers(columnNames);

	   loadTable(daDefaultTableModel);
	   
	    table.setModel(daDefaultTableModel);
	    JScrollPane scrollPane = new JScrollPane(table);
	    scrollPane.setBounds(10, 38, 414, 320);
	    frame.getContentPane().add(scrollPane);



	  }
	
		
	

	public void loadTable(DefaultTableModel daDefaultTableModel) {
		for(User u : User.userList() ) {
		    daDefaultTableModel.addRow(new Object[] {u.getUserID(), u.getName()});

		}
		
		
	}
	
	
}
