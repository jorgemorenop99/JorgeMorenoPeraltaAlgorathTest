package winB;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import algorath.User;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddNewConnectionFrame extends JFrame {

	private JPanel contentPane;
	private JTextField IdField;
	private JTextField Id2Field;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddNewConnectionFrame frame = new AddNewConnectionFrame(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param al 
	 */
	public AddNewConnectionFrame(JFrame f) {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 386, 238);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton AddButton = new JButton("Add the new Connection");
		AddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id = 0;
				int id2=0;
				try {
					 id = Integer.parseInt(IdField.getText());
					 id2 = Integer.parseInt(Id2Field.getText());
					 
					 try {
							User u = new User(id);
							User aux = new User(id2);
							try {
								u.addConnection(id2);
								dispose();
							}catch(Exception ex){
								ErrorFrame f = new ErrorFrame("The given connection is already on the database");
								f.setVisible(true);
							}
							
						}catch(Exception ex){
							ErrorFrame f = new ErrorFrame("The user you want to connect is not on the database");
							f.setVisible(true);
						}
					 
				}catch(Exception ex){
					ErrorFrame f = new ErrorFrame("The values of the fields are not valid");
					f.setVisible(true);
				}
				
				
			}
		});
		AddButton.setBounds(97, 137, 188, 21);
		contentPane.add(AddButton);
		
		IdField = new JTextField();
		IdField.setBounds(23, 86, 96, 19);
		contentPane.add(IdField);
		IdField.setColumns(10);
		
		Id2Field = new JTextField();
		Id2Field.setBounds(212, 86, 96, 19);
		contentPane.add(Id2Field);
		Id2Field.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID of User 1:");
		lblNewLabel.setBounds(38, 63, 71, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID of User 2:");
		lblNewLabel_1.setBounds(226, 63, 69, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Add new Connection:");
		lblNewLabel_2.setFont(new Font("VAGRounded BT", Font.ITALIC, 18));
		lblNewLabel_2.setBounds(117, 28, 134, 13);
		contentPane.add(lblNewLabel_2);
	}
}
