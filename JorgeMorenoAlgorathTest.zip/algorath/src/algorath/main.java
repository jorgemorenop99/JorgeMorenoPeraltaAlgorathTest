package algorath;
import java.util.ArrayList;
import java.util.List;

public class main {

	public static void main(String[] args) {
		
		User ne = new User(2);
		
		
		
		
		System.out.println(ne.getStats());


		System.out.println("\n" + User.getAverage());
		
		
		
		
		for(User u : User.userList()) {
			System.out.println(u.getUsersConnected().size());
		}
		
		
			
		 
	}

}
