package algorath;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class User {
	
	private int userID;
	
	private String name;
	
	private List<User> usersConnected;
	
	public User(int userID) {
		BD bd = new BD();
		Object[] t = bd.Select("Select * from user where userID = " + userID + ";").get(0);
		this.userID = userID;
		this.name = (String) t[1];
	}
	
	public List<User> getUsersConnected() { //REFORMAT
		List<User> ans = new ArrayList<>();
		BD bd = new BD();
		List<Object[]> tl = bd.Select("Select user2 from connection WHERE user1 = "+ userID);
		tl.addAll( bd.Select("Select user1 from connection WHERE user2 = "+ userID));
		List<Integer> nums = new ArrayList<>();
		for(Object[] t : tl) {
			int id = (int)t[0];
			User aux = new User(id);
			ans.add(aux);
		}
		
		return ans;
	}

	

	

	public User(int id, String name){
		BD bd = new BD();
		bd.Insert("INSERT INTO user VALUES('" + id + "', '" + name + "');");
        this.userID = id;
        this.name = name;
    }
	
	
	public static List<User> userList()
    {
        List<User> list = new ArrayList<>();
		BD bd = new BD();
        for (Object[] t : bd.Select("SELECT userID FROM user;"))
        {
            int id = (int)t[0];
            User u = new User(id);
            list.add(u);
        }

        return list;
    }

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		BD bd = new BD();
        bd.Update("UPDATE user SET userID = '" + userID
            + "' WHERE userID='" + this.userID + "';");
        this.userID = userID;	
    }
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		BD bd = new BD();
        bd.Update("UPDATE user SET name = '" + name
            + "' WHERE userID='" + this.userID + "';");
        this.name = name;	
	}
	
	
	 public void deleteUser()
     {
		 BD bd = new BD();
         bd.Delete("DELETE FROM user WHERE userID='" + this.userID + "';");

         this.userID = 0;
         this.name = null;
     }
	 
	 public void addConnection(int id) {
		 if(this.userID == id) throw new Error("Can not connect an user whith himself");
		 else {
			 try {
				 User aux = new User(id); // We check he is already on the db
			 }catch (Exception e){
				 throw new Error("The user you want to connect is not on the database");
			 }
			 int dis = userID;
			 if(id < userID) {
				 int n = id;
				 id = dis;
				 dis = n;
			 }
			 BD bd = new BD();
				bd.Insert("INSERT INTO connection VALUES('" + dis + "', '" + id + "');");
		 }
	 }
	 
	 public void deleteConnection( int id2) {
		 int id1 = this.userID;
		if(id2 < id1) {
			int n = id1;
			id1 = id2;
		 	id2 = n;
		 	System.out.println("Cambio");
		}
			 BD bd = new BD();
			 bd.Delete("Delete FROM connection where user1 = " + id1 + " AND user2 = " + id2 + ";");
		 
	 }
	 
	 public static double getAverage() {
		 double avrg = 0;
		 for(User u : User.userList()){
			 avrg = avrg + u.getUsersConnected().size();
		 }
		 avrg = avrg / User.userList().size();
		return avrg;
	 }
	 
	 public double getStats() {
		 double numUsers = User.userList().size()-1;
		 double usersWithLessConnections = 0;
		 double myConnections = this.getUsersConnected().size();
		 for(User u : User.userList()) {
			 if(u.getUsersConnected().size() < myConnections) usersWithLessConnections ++;
		 }
		 return (usersWithLessConnections / numUsers)*100;
	 }
	 
	public String toString() {
		return "("+ userID  + ", " + name + ")";
	}

	

	@Override
	public boolean equals(Object obj) {
		return obj instanceof User && ((User)obj).getUserID() == this.getUserID();
	}
	

	
}
