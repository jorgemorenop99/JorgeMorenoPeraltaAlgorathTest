CREATE DATABASE `algorathtest` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_general_mysql500_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;


CREATE TABLE `connection` (
  `user1` int NOT NULL,
  `user2` int NOT NULL,
  PRIMARY KEY (`user1`,`user2`),
  KEY `fk_user2_idx` (`user2`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user1`) REFERENCES `user` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user2` FOREIGN KEY (`user2`) REFERENCES `user` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_spanish2_ci;

CREATE TABLE `user` (
  `userID` int NOT NULL,
  `name` varchar(45) COLLATE utf8_general_mysql500_ci NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_general_mysql500_ci;


